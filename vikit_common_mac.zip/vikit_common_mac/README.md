# vikit_common_mac
 This repository works for my mac. Compatible with Sophus and deprecated Eigen library stuff
